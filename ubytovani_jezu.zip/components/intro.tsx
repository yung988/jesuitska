import Image from "next/image"

export default function Intro() {
  return (
    <section id="intro" className="py-24 md:py-32 px-6 md:px-20 max-w-7xl mx-auto">
      <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif tracking-wider uppercase text-center mb-4">
        Vítejte v ráji
      </h2>
      <div className="w-24 h-px bg-dark-gray/30 mx-auto mb-12"></div>

      <div className="grid md:grid-cols-2 gap-16 items-center">
        <div>
          <p className="text-lg md:text-xl mb-8 leading-relaxed">
            Náš luxusní resort nabízí jedinečný zážitek, kde se elegance setkává s přírodou. Každý detail byl pečlivě
            navržen tak, aby vytvořil harmonické prostředí pro váš dokonalý odpočinek.
          </p>
          <p className="text-lg md:text-xl mb-8 leading-relaxed">
            Obklopeni olivovými háji a s výhledem na azurové moře, naše suity představují dokonalou rovnováhu mezi
            moderním luxusem a tradiční architekturou.
          </p>
        </div>
        <div className="relative h-[500px] rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=1000&width=800"
            alt="Luxusní interiér resortu"
            fill
            className="object-cover"
          />
        </div>
      </div>
    </section>
  )
}
