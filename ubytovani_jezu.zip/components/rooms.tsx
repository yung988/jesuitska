"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Users, Maximize, Coffee, Wifi } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const roomTypes = [
  {
    id: "deluxe",
    name: "DELUXE SUITE",
    description:
      "Naše Deluxe Suite nabízí prostorný a elegantní interiér s výhledem na moře. Každý detail byl pečlivě navržen pro váš maximální komfort.",
    capacity: "2 osoby",
    size: "45 m²",
    features: ["Klimatizace", "Minibar", "Wifi", "Kávovar"],
    images: [
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
  {
    id: "premium",
    name: "PREMIUM SUITE",
    description:
      "Premium Suite představuje vrchol luxusu s prostornou terasou a soukromým bazénem. Interiér je zařízen v minimalistickém stylu s důrazem na přírodní materiály.",
    capacity: "3 osoby",
    size: "65 m²",
    features: ["Klimatizace", "Minibar", "Wifi", "Kávovar", "Soukromý bazén"],
    images: [
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
  {
    id: "family",
    name: "RODINNÁ VILA",
    description:
      "Rodinná vila poskytuje dostatek prostoru pro celou rodinu. S oddělenými ložnicemi a prostorným obývacím prostorem je ideální pro delší pobyt.",
    capacity: "4-6 osob",
    size: "95 m²",
    features: ["Klimatizace", "Plně vybavená kuchyně", "Wifi", "Kávovar", "Terasa"],
    images: [
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
]

export default function Rooms() {
  const [activeTab, setActiveTab] = useState("deluxe")
  const [currentImage, setCurrentImage] = useState(0)

  const activeRoom = roomTypes.find((room) => room.id === activeTab)

  const nextImage = () => {
    if (activeRoom) {
      setCurrentImage((prev) => (prev === activeRoom.images.length - 1 ? 0 : prev + 1))
    }
  }

  const prevImage = () => {
    if (activeRoom) {
      setCurrentImage((prev) => (prev === 0 ? activeRoom.images.length - 1 : prev - 1))
    }
  }

  return (
    <section id="rooms" className="py-24 md:py-32 px-6 md:px-20 bg-cream/50">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif tracking-wider uppercase text-center mb-4">
          Ubytování
        </h2>
        <div className="w-24 h-px bg-dark-gray/30 mx-auto mb-12"></div>

        <p className="text-center mb-12 max-w-2xl mx-auto text-lg">
          Vyberte si z našich luxusních apartmánů, každý navržený s důrazem na detail a komfort.
        </p>

        <div className="flex justify-center gap-4 mb-16">
          {roomTypes.map((room) => (
            <Button
              key={room.id}
              variant="outline"
              className={cn(
                "rounded-full px-6 py-6 uppercase tracking-widest text-sm border-none",
                activeTab === room.id ? "bg-purple text-white hover:bg-purple/90" : "bg-cream hover:bg-cream/90",
              )}
              onClick={() => {
                setActiveTab(room.id)
                setCurrentImage(0)
              }}
            >
              {room.name}
            </Button>
          ))}
        </div>

        {activeRoom && (
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              <h3 className="text-2xl font-serif mb-6">{activeRoom.name}</h3>
              <p className="text-lg mb-10 leading-relaxed">{activeRoom.description}</p>

              <h4 className="uppercase tracking-widest text-sm mb-4">Vlastnosti:</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-purple" />
                  <span>Kapacita: {activeRoom.capacity}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Maximize className="h-5 w-5 text-purple" />
                  <span>Velikost: {activeRoom.size}</span>
                </div>
                {activeRoom.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    {feature.includes("Wifi") ? (
                      <Wifi className="h-5 w-5 text-purple" />
                    ) : feature.includes("Kávovar") ? (
                      <Coffee className="h-5 w-5 text-purple" />
                    ) : (
                      <div className="h-5 w-5 rounded-full bg-purple/20 flex items-center justify-center">
                        <div className="h-2 w-2 rounded-full bg-purple"></div>
                      </div>
                    )}
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <Button className="rounded-full bg-dark-gray text-white px-8 py-6 uppercase tracking-widest text-sm hover:bg-black transition-colors">
                Rezervovat
              </Button>
            </div>

            <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden">
              <Image
                src={activeRoom.images[currentImage] || "/placeholder.svg"}
                alt={`${activeRoom.name} - obrázek ${currentImage + 1}`}
                fill
                className="object-cover"
              />

              <div className="absolute bottom-6 right-6 flex gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  className="rounded-full bg-cream/30 backdrop-blur-sm hover:bg-cream/50 border-none"
                  onClick={prevImage}
                >
                  <ChevronLeft className="h-5 w-5" />
                  <span className="sr-only">Předchozí</span>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="rounded-full bg-cream/30 backdrop-blur-sm hover:bg-cream/50 border-none"
                  onClick={nextImage}
                >
                  <ChevronRight className="h-5 w-5" />
                  <span className="sr-only">Další</span>
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
